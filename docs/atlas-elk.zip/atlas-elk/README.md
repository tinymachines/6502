# atlas → ELK

**Contents:** `atlas2elk.js` converter, `elk2svg.js` renderer, `run.sh` to rebuild
everything, `svg/` four renders, `atlasfull.json` a snapshot of the endpoint.
The snapshot carries no build stamp, so it cannot be tied to a netlist revision
— re-fetch with `./run.sh --fetch` if that matters.


Converts `/v1/atlas/full` into an ELK graph and lays it out. No hand-placement.

    curl -s --compressed https://6502.tinymachines.ai/api/v1/atlas/full -o atlasfull.json
    npm install elkjs
    DIR=RIGHT PLACE=NETWORK_SIMPLEX MIN_GATE=8 node atlas2elk.js
    node elk2svg.js          # -> atlas-elk.svg, prints edges + crossings

`bash run.sh` rebuilds all four renders in `svg/`:

| file | direction | MIN_GATE | edges | crossings |
|---|---|---:|---:|---:|
| `atlas-right-8.svg` | RIGHT | 8 | 62 | 73 |
| `atlas-right-4.svg` | RIGHT | 4 | 106 | 350 |
| `atlas-right-16.svg` | RIGHT | 16 | 20 | 3 |
| `atlas-down-8.svg` | DOWN | 8 | 62 | 74 |

Start with `atlas-right-8.svg`.

## The mapping

| atlas | ELK |
|---|---|
| `kinds` (23) | top-level containers |
| `groups` (132), via `parent`/`depth` | nested children, 2 levels |
| `bundles` (534), `a`/`b` | edges; `gate + switch` is the weight |
| `bundles[].controls` | drawn ochre |
| `ab` / `ba` | arrowheads |
| `gate == 0` | dashed cyan, no arrowheads |

`bundles` is the abstraction that makes this tractable. ELK never sees a
transistor — it lays out 132 groups and finishes in ~5s.

## MIN_GATE is the readability knob

Median bundle weight is **1**; 381 of 534 are weight ≤2, a long tail of
single-transistor links. Pruning them, not tuning the algorithm, is what
makes the picture legible.

| MIN_GATE | edges | crossings |
|---:|---:|---:|
| 0 | 534 | 12,729 |
| 4 | 106 | 350 |
| 8 | 62 | 73 |
| 16 | 20 | 3 |

## Direction falls out of the data

`ab + ba == gate` holds for **every** bundle. Splitting on it:

- 202 forward-only, 256 reverse-only, 16 bidirectional — drawn with arrowheads
- 60 with no direction, and **all 60 have `gate == 0`** — pure `switch`
  connections, i.e. bidirectional pass transistors. They get no arrowhead and
  a dashed stroke, because direction is not a property they have.

`regs:s ↔ sbus:sb` is the clean example: 16 switch connections, zero gate,
controlled by `dpc4_SSB` and `dpc6_SBS` — S drives SB or SB drives S depending
on which control line is high.

## Layout options: what actually mattered

Swept at MIN_GATE=8. Only one option moved the needle.

| config | crossings | size | aspect |
|---|---:|---|---:|
| layered DOWN (baseline) | 74 | 9146 × 1180 | 7.75 |
| **layered RIGHT** | 73 | 2251 × 3475 | 0.65 |
| RIGHT + NETWORK_SIMPLEX | 73 | 2291 × 3162 | 0.72 |
| RIGHT + POLYLINE / SPLINES | 73 / 81 | — | — |
| thoroughness 30 → 100 | 73 | identical | — |

Three things that look like knobs and are not:

- **`elk.aspectRatio` is ignored by `layered`.** Output byte-identical with and
  without it. It is honoured by packing algorithms (`rectpacking`, `box`), not
  by layered.
- **`elk.layered.wrapping.strategy` is the documented aspect control for
  layered, and it also did nothing here** — identical output at MIN_GATE=8 for
  OFF / SINGLE_EDGE / MULTI_EDGE. It only engages once the graph is deep
  enough in layers; at 62 edges it never triggers. At MIN_GATE=0 it does fire
  (13384 × 7866, aspect 1.70).
- **`SEPARATE_CHILDREN` appears to give zero crossings. It does not.** It lays
  each container out independently and leaves cross-container edges unrouted —
  only **9 of 62** edges came back with `sections`. The crossing count was
  measuring a picture with the edges missing. Use `INCLUDE_CHILDREN`, which
  flattens the hierarchy into a single layered pass; the cost is that
  per-container `elk.direction` / `elk.algorithm` are then ignored.

## Still rough

- Aspect is portrait (0.72) and not controllable without giving up routed
  cross-container edges. Fine for a scrolling page, awkward for a slide.
- Some container labels still crowd their box.
- Leaf boxes are sized from `count`, which is a proxy for area, not for how
  much wiring the group actually carries.
