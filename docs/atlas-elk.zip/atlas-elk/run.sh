#!/bin/bash
# Rebuild every SVG in svg/ from atlasfull.json.  Usage: bash run.sh [--fetch]
set -e
cd "$(dirname "$0")"
[ -d node_modules ] || npm install --silent
[ "$1" = "--fetch" ] && curl -s --compressed \
  https://6502.tinymachines.ai/api/v1/atlas/full -o atlasfull.json
mkdir -p svg
build(){ # dir min_gate name
  DIR=$1 PLACE=NETWORK_SIMPLEX MIN_GATE=$2 OUT=/tmp/elk-$3.json node atlas2elk.js
  OUT=/tmp/elk-$3.json SVG=svg/$3.svg node elk2svg.js
}
build RIGHT 8  atlas-right-8      # the readable one
build RIGHT 4  atlas-right-4      # more detail, ~5x the crossings
build RIGHT 16 atlas-right-16     # skeleton: the heaviest bundles only
build DOWN  8  atlas-down-8       # why RIGHT won
echo "done -> svg/"
