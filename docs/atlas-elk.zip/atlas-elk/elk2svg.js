const fs = require('fs');
const r = JSON.parse(fs.readFileSync(process.env.OUT||'elk-out.json', 'utf8'));

const KIND_HUE = { regs:'#7dd3fc', flags:'#fca5a5', alat:'#67e8f9', dbus:'#fda4af',
  irp:'#c4b5fd', alu:'#fbbf24', pc:'#86efac', stage:'#f0abfc', pads:'#94a3b8' };
const hueFor = id => KIND_HUE[String(id).replace(/^kind:/,'').split(':')[0]] || '#8ea3c0';

const boxes = [], labels = [];
(function walk(n, ox, oy) {
  for (const c of n.children || []) {
    const x = ox + (c.x||0), y = oy + (c.y||0);
    const isKind = c.id.startsWith('kind:');
    boxes.push({ x, y, w: c.width||0, h: c.height||0, isKind, id: c.id,
                 hue: hueFor(c.id), leaf: !(c.children||[]).length });
    if (c.labels?.[0]) labels.push({ x: x+8, y: y+(isKind?20:22), t: c.labels[0].text,
                                     isKind, hue: hueFor(c.id) });
    walk(c, x, y);
  }
})(r, 0, 0);

// edge polylines, resolving section coords
const segs = [], paths = [];
function collect(n, ox, oy) {
  for (const e of n.edges || []) {
    const pts = [];
    for (const s of e.sections || []) {
      pts.push([ox+s.startPoint.x, oy+s.startPoint.y]);
      for (const b of s.bendPoints || []) pts.push([ox+b.x, oy+b.y]);
      pts.push([ox+s.endPoint.x, oy+s.endPoint.y]);
    }
    if (pts.length > 1) {
      paths.push({ pts, w: e.weight||1, ctl: (e.controls||[]).length,
                   ab: e.ab||0, ba: e.ba||0 });
      for (let i=0;i<pts.length-1;i++) segs.push([pts[i],pts[i+1]]);
    }
  }
  for (const c of n.children || []) collect(c, ox+(c.x||0), oy+(c.y||0));
}
collect(r, 0, 0);

// crossing count (segment intersection, excluding shared endpoints)
function cross(p,q,a,b){
  const d=(x,y,z)=>Math.sign((y[0]-x[0])*(z[1]-x[1])-(y[1]-x[1])*(z[0]-x[0]));
  const same=(u,v)=>Math.abs(u[0]-v[0])<1e-6&&Math.abs(u[1]-v[1])<1e-6;
  if(same(p,a)||same(p,b)||same(q,a)||same(q,b))return false;
  return d(p,q,a)*d(p,q,b)<0 && d(a,b,p)*d(a,b,q)<0;
}
let X=0;
for(let i=0;i<segs.length;i++)for(let j=i+1;j<segs.length;j++)
  if(cross(segs[i][0],segs[i][1],segs[j][0],segs[j][1]))X++;

const W=Math.round(r.width), H=Math.round(r.height);
const out=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="IBM Plex Mono, monospace">`,
`<rect width="${W}" height="${H}" fill="#0b1120"/>`];
for(const b of boxes){
  if(b.isKind) out.push(`<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="10" fill="#111c33" stroke="${b.hue}" stroke-opacity=".35"/>`);
  else out.push(`<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="6" fill="${b.leaf?'#16233d':'#0f1a2e'}" stroke="${b.hue}" stroke-opacity=".7"/>`);
}
out.push(`<defs>
<marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,1 L9,5 L0,9 z" fill="#5b7fb0"/></marker>
<marker id="ahc" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,1 L9,5 L0,9 z" fill="#fbbf24"/></marker>
<marker id="ahr" viewBox="0 0 10 10" refX="1" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M9,1 L0,5 L9,9 z" fill="#5b7fb0"/></marker>
</defs>`);
for(const p of paths){
  const sw = Math.max(.7, Math.min(4.5, Math.log2(p.w+1)*.75));
  const col = p.ctl ? '#fbbf24' : '#5b7fb0';
  const fwd = p.ab > 0, rev = p.ba > 0;
  const pass = !fwd && !rev;
  const m = [];
  if (fwd) m.push(`marker-end="url(#${p.ctl?'ahc':'ah'})"`);
  if (rev) m.push(`marker-start="url(#ahr)"`);
  out.push(`<polyline points="${p.pts.map(q=>q[0].toFixed(1)+','+q[1].toFixed(1)).join(' ')}" fill="none" stroke="${pass?'#67e8f9':col}" stroke-opacity="${p.ctl?.8:.5}" stroke-width="${sw.toFixed(2)}" ${pass?'stroke-dasharray="7 5"':''} ${m.join(' ')}/>`);
}
for(const l of labels)
  out.push(`<text x="${l.x}" y="${l.y}" font-size="${l.isKind?15:12}" fill="${l.isKind?l.hue:'#d6e2f5'}" ${l.isKind?'letter-spacing="1.5"':''}>${l.t.replace(/&/g,'&amp;').replace(/</g,'&lt;')}</text>`);
out.push('</svg>');
fs.writeFileSync(process.env.SVG||'atlas-elk.svg', out.join('\n'));
console.log(`boxes ${boxes.length}  edges ${paths.length}  segments ${segs.length}`);
console.log(`crossings ${X}   size ${W} x ${H}`);
