// atlas -> ELK.  Groups become nested nodes, bundles become weighted edges.
const fs = require('fs');
const ELK = require('elkjs');
const atlas = JSON.parse(fs.readFileSync('atlasfull.json', 'utf8'));

const MIN_GATE = Number(process.env.MIN_GATE || 0);   // prune weak bundles
const byKey = new Map(atlas.groups.map(g => [g.key, g]));

// kinds are the real top level: every depth-1 group hangs off a kind
const kinds = new Map(atlas.kinds.map(k => [k.key, k]));

function mkNode(g) {
  const text = `${g.label}  ·${g.count}`;
  const w = Math.max(72, text.length * 7.6 + 20, Math.min(190, 34 + g.count * 3.0));
  return {
    id: g.key,
    labels: [{ text }],
    width: w, height: 34,
    children: [], edges: [],
    layoutOptions: { 'elk.padding': '[top=30,left=12,bottom=12,right=12]' },
  };
}

const nodes = new Map();
for (const g of atlas.groups) nodes.set(g.key, mkNode(g));

// build the kind containers
const kindNodes = new Map();
for (const [key, k] of kinds) {
  kindNodes.set(key, {
    id: `kind:${key}`,
    labels: [{ text: k.label.toUpperCase() }],
    children: [], edges: [],
    layoutOptions: {
      'elk.padding': '[top=34,left=14,bottom=14,right=14]',
      'elk.algorithm': process.env.KALGO || 'layered',
      'elk.direction': process.env.KDIR || 'RIGHT',
      'elk.aspectRatio': process.env.KAR || '3.2',
    },
  });
}

// nest: depth-2 groups inside their parent, depth-1 inside their kind
for (const g of atlas.groups) {
  const n = nodes.get(g.key);
  if (g.depth === 2 && byKey.has(g.parent)) nodes.get(g.parent).children.push(n);
  else (kindNodes.get(g.kind) || { children: [] }).children.push(n);
}

// a node with children gets sized by ELK, not by us
for (const n of nodes.values()) if (n.children.length) { delete n.width; delete n.height; }

const root = {
  id: 'root',
  layoutOptions: {
    'elk.algorithm': process.env.ALGO || 'layered',
    'elk.direction': process.env.DIR || 'DOWN',
    'elk.layered.crossingMinimization.strategy': process.env.CROSS || 'LAYER_SWEEP',
    'elk.layered.thoroughness': process.env.THOR || '30',
    'elk.layered.nodePlacement.strategy': process.env.PLACE || 'BRANDES_KOEPF',
    'elk.spacing.nodeNode': process.env.SPN || '26',
    'elk.layered.spacing.nodeNodeBetweenLayers': process.env.SPL || '46',
    'elk.hierarchyHandling': process.env.HIER || 'INCLUDE_CHILDREN',
    'elk.edgeRouting': process.env.ROUTE || 'ORTHOGONAL',
    ...(process.env.AR ? {'elk.aspectRatio': process.env.AR} : {}),
    ...(process.env.WRAP ? {
      'elk.layered.wrapping.strategy': process.env.WRAP,
      'elk.layered.wrapping.correctionFactor': process.env.WCF || '1.0',
      'elk.layered.wrapping.additionalEdgeSpacing': process.env.WES || '10',
    } : {}),
  },
  children: [...kindNodes.values()].filter(k => k.children.length),
  edges: [],
};

// bundles -> edges, deduped and pruned
let kept = 0, dropped = 0;
const seen = new Set();
for (const b of atlas.bundles) {
  if (!nodes.has(b.a) || !nodes.has(b.b) || b.a === b.b) { dropped++; continue; }
  const total = b.gate + b.switch;
  if (total < MIN_GATE) { dropped++; continue; }
  const k = b.a < b.b ? `${b.a}|${b.b}` : `${b.b}|${b.a}`;
  if (seen.has(k)) { dropped++; continue; }
  seen.add(k);
  root.edges.push({
    id: `e${kept}`, sources: [b.a], targets: [b.b],
    weight: total, gate: b.gate, switch: b.switch, controls: b.controls,
  });
  kept++;
}

console.error(`groups ${atlas.groups.length}  kinds ${kindNodes.size}  edges kept ${kept} dropped ${dropped}`);

new ELK().layout(root).then(res => {
  fs.writeFileSync(process.env.OUT||'elk-out.json', JSON.stringify(res));
  console.error(`layout ${Math.round(res.width)} x ${Math.round(res.height)}`);
}).catch(e => { console.error('FAILED', e.message); process.exit(1); });
